"""
This file contains utility functions.
"""

import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import os
from datetime import datetime

def detect_anomalies(sess, model, fw, epoch, thd):
    # Detect anomalies
    sess.run(tf.local_variables_initializer())
    while True:
        try:
            sess.run(model.metric_updates, feed_dict={model.gen_sample_batch_size: 1, model.b_replay: False})
        except tf.errors.OutOfRangeError:
            break
    [metrics, summaries] = sess.run([model.metrics, model.merged_summaries])
    print("+---------------------------")
    print("| Metrics:")
    for m, m_n in zip(metrics, model.metric_names):
        print("|» " + m_n + ": " + str(m))
    print("+---------------------------")
    # Write metrics to tensorboard
    fw.add_summary(summaries, epoch)
    return metrics

def initialize_train_data(sess, task, iterator, data, labels, batch_size, data_ph, labels_ph, batch_size_ph, shufflebuffer_ph):
    curr_batch_size = np.floor(batch_size/(task+1.0))
    repl_batch_size = batch_size - curr_batch_size
    sess.run(iterator.initializer, feed_dict={data_ph: data, labels_ph: labels, batch_size_ph: curr_batch_size, shufflebuffer_ph: data.shape[0]})

def initialize_eval_data(sess, iterator, data, labels, batch_size, data_ph, labels_ph, batch_size_ph, shufflebuffer_ph, thd_1):
    sess.run(iterator.initializer, feed_dict={data_ph: data, labels_ph: labels, batch_size_ph: batch_size, shufflebuffer_ph: data.shape[0]})

def train(sess, task, model, epochs, iterator, data, labels, batch_size, data_ph, labels_ph, batch_size_ph, shufflebuffer_ph):
    curr_batch_size = np.floor(batch_size/(task+1.0))
    repl_batch_size = batch_size - curr_batch_size
    if (task > 0):
        b_replay = True
    else:
        b_replay = False
    for i in range(epochs):
        initialize_train_data(sess, task, iterator, data, labels, curr_batch_size, data_ph, labels_ph, batch_size_ph, shufflebuffer_ph)
        while True:
            try:
                [_, loss] = sess.run([model.update, model.loss], feed_dict={model.gen_sample_batch_size: repl_batch_size, model.b_replay: b_replay})
    
            except tf.errors.OutOfRangeError:
                break
        print("Epoch: {}\tloss: {:.5}".format(i, loss))
    model.update_gen_weights(sess)

def metrics_saver(metrics_list, metric_names, hp_dict, log_path):
    # Create log path if it does not exist
    dt = datetime.now().strftime("%Y_%m_%d_%H_%M")
    filename = log_path+"/"+dt+"/"+"log.txt"
    os.makedirs(log_path+"/"+dt, exist_ok=True)
    # Compute average metrics and save them
    metrics_np = np.concatenate(metrics_list, axis=0)
    np.save(log_path+"/"+dt+"/metrics", metrics_np)
    # Save hyperparameters and metrics in a log folder
    with open(filename, "w") as f:
        f.write("+---------------------------+\n")
        f.write("| Metrics                   |\n")
        f.write("+---------------------------+\n")
        for m_n in metric_names:
            f.write(m_n.ljust(4)+"\t\t")
        f.write("\n")
        for metrics in metrics_list:
            for i, m in enumerate(metrics):
                if (i < 4):
                    f.write("%1.3f\t\t" % (m))
                else:
                    f.write("%4d\t\t" % (m))
            f.write("\n")
        f.write("+---------------------------+\n")
        f.write("| Hyperparameters           |\n")
        f.write("+---------------------------+\n")
        for key, val in hp_dict.items():
            f.write(key.ljust(25)+": "+str(val)+"\n")

def plot_gen_imgs(sess, model, gen_sample_batch_size, log_path_dt, i):
    img_len = np.int32(np.sqrt(gen_sample_batch_size))
    gen_imgs = sess.run(model.gen.output, feed_dict={model.gen_sample_batch_size: gen_sample_batch_size, model.b_replay: False})
    img = np.zeros((28*img_len, 28*img_len), dtype=np.float32)
    for j in range(img_len):
        for k in range(img_len):
            img[j*28:(j+1)*28, k*28:(k+1)*28] = np.reshape(gen_imgs[j*img_len+k, :], [28, 28])
    plt.imshow(img)
    fname = log_path_dt+"/gen_imgs_"+str(i)
    plt.savefig(fname, format="png")
    plt.close()

def plot_recon_imgs(sess, model, gen_sample_batch_size, log_path_dt, i):
    img_len = np.int32(np.sqrt(gen_sample_batch_size))
    [in_imgs, recon_imgs] = sess.run([model.input, model.recon], feed_dict={model.gen_sample_batch_size: gen_sample_batch_size, model.b_replay: False})
    img = np.zeros((2*28*img_len, 28*img_len), dtype=np.float32)
    for j in range(img_len):
        for k in range(img_len):
            img[j*28:(j+1)*28, k*28:(k+1)*28] = np.reshape(in_imgs[j*img_len+k, :], [28, 28])
    for j in range(img_len):
        for k in range(img_len):
            img[img_len*28+j*28:img_len*28+(j+1)*28, k*28:(k+1)*28] = np.reshape(recon_imgs[j*img_len+k, :], [28, 28])
    plt.imshow(img)
    fname = log_path_dt+"/recon_imgs_"+str(i)
    plt.savefig(fname, format="png")
    plt.close()

def plot_anomscore(sess, model, log_path_dt, i):
    anomaly_score = []
    label = []
    while True:
        try:
            [an_scr, lbl] = sess.run([model.anomaly_score, model.label], feed_dict={model.gen_sample_batch_size: 1, model.b_replay: False})
            anomaly_score.append(an_scr)
            label.append(lbl)
        except tf.errors.OutOfRangeError:
            break
    anomaly_score = np.concatenate(anomaly_score)
    label = np.concatenate(label)
    plt.hist([anomaly_score[label == 0], anomaly_score[label == 1]], 100)
    plt.legend(["Normal", "Anomaly"])
    plt.title("Histogram of anomaly score")
    fname = log_path_dt+"/anomaly_score_"+str(i)
    plt.savefig(fname, format="png")
    plt.close()

def create_tensorboard(sess, log_path, hp_dict):
    # Create log path if it does not exist
    dt = datetime.now().strftime("%Y_%m_%d_%H_%M")
    log_path_dt = log_path+"/"+dt
    filename = log_path_dt+"/"+"log.txt"
    os.makedirs(log_path_dt, exist_ok=True)
    # Write hyperparameters to file
    with open(filename, "w") as f:
        f.write("+---------------------------+\n")
        f.write("| Hyperparameters           |\n")
        f.write("+---------------------------+\n")
        for key, val in hp_dict.items():
            f.write(key.ljust(25)+": "+str(val)+"\n")
    # Create tensorboard FileWriter
    fw = tf.summary.FileWriter(log_path_dt, sess.graph, flush_secs=1)
    return fw, log_path_dt
