"""
Test script for continual anomaly detection.
"""

import datasets
import models
import utils
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import os

# Constants
pic_size = 28*28
code_size = 50
dec_neurons = [128, 256, 512]
disc_neurons = [512, 256, 128]
batch_size = 32
learning_rate = 0.0001
epochs = 1000

# Create dataset and batching using tensorflow
data_ph = tf.placeholder(tf.float32)
labels_ph = tf.placeholder(tf.float32)
batch_size_ph = tf.placeholder(tf.int64)
shufflebuffer_ph = tf.placeholder(tf.int64)
data_ds = tf.data.Dataset.from_tensor_slices(data_ph)
labels_ds = tf.data.Dataset.from_tensor_slices(labels_ph)
dataset = tf.data.Dataset.zip((data_ds, labels_ds)).shuffle(shufflebuffer_ph).batch(batch_size_ph)
iterator = dataset.make_initializable_iterator()
[batch_data, batch_labels] = iterator.get_next()

# Create WGAN
WGAN = models.dense_wasserstein_gan(batch_data, pic_size, code_size, dec_neurons, disc_neurons, batch_size)

# Build optimizer
learning_rate_ph = tf.placeholder(tf.float32)
opt_disc = tf.train.RMSPropOptimizer(learning_rate_ph)
opt_gen = tf.train.RMSPropOptimizer(learning_rate_ph)
update_disc = opt_disc.minimize(WGAN.loss_disc, var_list=tf.trainable_variables("dense_discriminator_vars"))
update_gen = opt_gen.minimize(WGAN.loss_gen, var_list=tf.trainable_variables("decoder_vars"))

# Start tf session
sess = tf.Session()
sess.run([tf.global_variables_initializer(), tf.local_variables_initializer()])

# Create output folder
if (not os.path.exists("out_wasserstein/")):
    os.makedirs("out_wasserstein/")

for i in range(epochs):
    # Load data for training
    data = datasets.mnist()
    [train_data, train_labels] = data.get_train_samples()
    train_data = train_data / 255.0

    # Initialize iterator
    sess.run(iterator.initializer, feed_dict={data_ph: train_data, labels_ph: train_labels, batch_size_ph: batch_size, shufflebuffer_ph: train_data.shape[0]})

    # Train WGAN
    while True:
        try:
            [_, _, loss_disc] = sess.run([update_disc, WGAN.clip, WGAN.loss_disc], feed_dict={learning_rate_ph: learning_rate})
            [_, loss_gen] = sess.run([update_gen, WGAN.loss_gen], feed_dict={learning_rate_ph: learning_rate})
        except tf.errors.OutOfRangeError:
            break
    print("Epoch: {}\tloss_disc: {:.4}\tloss_gen: {:.4}".format(i, loss_disc, loss_gen))

    if (i % 10 == 0):
        # Generate images
        WGAN.update_gen_weights(sess)
        gen_img_batch = sess.run(WGAN.gen.output)
        img = np.zeros((28*4, 28*4), dtype=np.float32)
        for j in range(4):
            for k in range(4):
                img[j*28:(j+1)*28, k*28:(k+1)*28] = np.reshape(gen_img_batch[j*4+k, :], [28, 28])
        plt.imshow(img)
        plt.savefig("out_wasserstein/{}.png".format(str(i).zfill(3)))
        plt.close()
