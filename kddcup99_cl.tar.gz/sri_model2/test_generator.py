"""
Test script for continual anomaly detection.
"""

import datasets
import models
import utils
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# Constants
output_size = 28*28
enc_neurons = [400, 300, 200, 100]
code_size = 50
dec_neurons = [100, 200, 300, 400]
batch_size = 128
learning_rate = 0.001
epochs = 25
eval_posterior_samples = 100
gen_sample_batch_size = 512

# Create dataset and batching using tensorflow
data_ph = tf.placeholder(tf.float32)
labels_ph = tf.placeholder(tf.float32)
batch_size_ph = tf.placeholder(tf.int64)
shufflebuffer_ph = tf.placeholder(tf.int64)
data_ds = tf.data.Dataset.from_tensor_slices(data_ph)
labels_ds = tf.data.Dataset.from_tensor_slices(labels_ph)
dataset = tf.data.Dataset.zip((data_ds, labels_ds)).shuffle(shufflebuffer_ph).batch(batch_size_ph)
iterator = dataset.make_initializable_iterator()
[batch_data, batch_labels] = iterator.get_next()

# Create VAE
posterior_samples_ph = tf.placeholder(tf.int32, shape=[])
gen_sample_batch_size_ph = tf.placeholder(tf.int32, shape=[])
thd_ph = tf.placeholder(tf.float32, shape=[])
b_replay_ph = tf.placeholder(tf.bool, shape=[])
VAE = models.dense_VAE(batch_data, batch_labels, b_replay_ph, output_size, enc_neurons, code_size, dec_neurons, posterior_samples_ph, gen_sample_batch_size_ph, thd_ph)

# Build optimizer
learning_rate_ph = tf.placeholder(tf.float32)
opt = tf.train.AdamOptimizer(learning_rate_ph)
update = opt.minimize(-1.0*tf.reduce_mean(VAE.elbo))

# Start tf session
sess = tf.Session()
saver = tf.train.Saver()

# Load data for training
data = datasets.split_anomaly_mnist([1], [0])
[train_data, train_labels] = data.get_train_samples()
[eval_data, eval_labels] = data.get_eval_samples()
train_data = train_data / 255.0
eval_data = eval_data / 255.0

# Initialize optimizer
sess.run([tf.variables_initializer(opt.variables()), tf.local_variables_initializer(), tf.global_variables_initializer()])

# Run epochs
for i in range(epochs):
    # Initialize iterator
    sess.run(iterator.initializer, feed_dict={data_ph: eval_data, labels_ph: eval_labels, batch_size_ph: batch_size, shufflebuffer_ph: eval_data.shape[0]})

    [ll_val, kl_val, elbo_val] = sess.run([tf.reduce_mean(VAE.log_likelihood), tf.reduce_mean(VAE.kl_divergence), tf.reduce_mean(VAE.elbo)], feed_dict={posterior_samples_ph: 1, gen_sample_batch_size_ph: gen_sample_batch_size, b_replay_ph: False})
    print("Epoch: " + str(i) + " ELBO: " + str(elbo_val)+ " LL: " + str(ll_val) + " KL: " + str(kl_val))

    # Initialize iterator
    sess.run(iterator.initializer, feed_dict={data_ph: train_data, labels_ph: train_labels, batch_size_ph: batch_size, shufflebuffer_ph: train_data.shape[0]})

    # Update parameters
    while True:
        try:
            sess.run(update, feed_dict={learning_rate_ph: learning_rate, posterior_samples_ph: 1, gen_sample_batch_size_ph: batch_size, b_replay_ph: False})
        except tf.errors.OutOfRangeError:
            break

# Generate images
VAE.update_gen_weights(sess)
gen_img = sess.run(VAE.gen.output, feed_dict={loc["gen_sample_batch_size_ph"]: 400})
block = np.zeros((560, 560), np.float32)
for i in range(20):
    for j in range(20):
        block[i*28:(i+1)*28, j*28:(j+1)*28] = np.reshape(gen_img[i*10+j, :], [28, 28])
plt.imshow(block)
plt.show()
