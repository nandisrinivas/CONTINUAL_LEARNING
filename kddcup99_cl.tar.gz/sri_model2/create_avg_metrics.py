"""
This script is used to create average metrics.
"""

import numpy as np
import matplotlib.pyplot as plt

paths = ["./log/GAN/2021_01_19_16_08",\
        "./log/GAN/2021_01_19_16_11",\
        "./log/GAN/2021_01_19_16_17"]
         

metric_list = []
for p in paths:
    metrics = np.load(p+"/metrics.npy")
    metrics = np.transpose(np.reshape(metrics, [8, 1]))
    metric_list.append(metrics)

avg_metrics = np.zeros([8, 1])
for m in metric_list:
    avg_metrics += m
avg_metrics /= len(paths)

metric_names = ["acc", "auc", "prec", "rec", "tp", "fp", "tn", "fn"]
for i, m_n in enumerate(metric_names):
    y = avg_metrics[i, :]
    x = np.arange(1,y.shape[0]+1)
    data = np.transpose(np.vstack((x, y)))
    np.savetxt("./log/EWC/"+m_n+".csv", data, delimiter=",", header="a,b", comments="")
