"""
These classes provide models for training.
"""

import abc
import numpy as np
import tensorflow as tf

class model:
    """
    Base class for model.
    """
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def __init__(self):
        pass

class dense_encoder(model):
    """
    Dense encoder with arbitrary length and width.
    """

    def __init__(self, x, neurons, code_size, activation):
        self.vars = []
        output = x
        with tf.name_scope("dense_encoder"):
            with tf.variable_scope("encoder_vars", reuse=tf.AUTO_REUSE):
                # Build encoder network
                for i, n in enumerate(neurons):
                    w = tf.get_variable("w"+str(i), [output.shape[-1], n], initializer=tf.variance_scaling_initializer())
                    b = tf.get_variable("b"+str(i), [n], initializer=tf.zeros_initializer())
                    self.vars.append(w)
                    self.vars.append(b)
                    output = activation(tf.add(tf.matmul(output, w), b))
                # Build normal distribution with code_size
                self.code = output
                w = tf.get_variable("w_loc", [output.shape[-1], code_size], initializer=tf.variance_scaling_initializer())
                b = tf.get_variable("b_loc", [code_size], initializer=tf.zeros_initializer())
                self.vars.append(w)
                self.vars.append(b)
                self.loc = tf.add(tf.matmul(output, w), b)
                w = tf.get_variable("w_scale", [output.shape[-1], code_size], initializer=tf.variance_scaling_initializer())
                b = tf.get_variable("b_scale", [code_size], initializer=tf.zeros_initializer())
                self.vars.append(w)
                self.vars.append(b)
                self.scale = tf.nn.softplus(tf.add(tf.matmul(output, w), b))
                self.distribution = tf.distributions.Normal(self.loc, self.scale)

class dense_decoder(model):
    """
    Dense decoder with arbitrary length and width.
    """

    def __init__(self, x, output_size, neurons, activation):
        self.output_size = output_size
        self.neurons = neurons
        self.vars = []
        with tf.name_scope("dense_decoder"):
            with tf.variable_scope("decoder_vars", reuse=tf.AUTO_REUSE):
                output = x
                # Build encoder network
                for i, n in enumerate(neurons):
                    w = tf.get_variable("w"+str(i), [output.shape[-1], n], initializer=tf.variance_scaling_initializer())
                    b = tf.get_variable("b"+str(i), [n], initializer=tf.zeros_initializer())
                    self.vars.append(w)
                    self.vars.append(b)
                    output = activation(tf.add(tf.matmul(output, w), b))
                # Build normal distribution with code_size
                w = tf.get_variable("w_loc", [output.shape[-1], output_size], initializer=tf.variance_scaling_initializer())
                b = tf.get_variable("b_loc", [output_size], initializer=tf.zeros_initializer())
                self.vars.append(w)
                self.vars.append(b)
                output = tf.add(tf.matmul(output, w), b)
                self.output = tf.reshape(tf.nn.sigmoid(output), [-1, output_size])
                self.distribution = tf.distributions.Bernoulli(output)

class dense_generator(model):
    """
    Dense generator based on a given decoder.
    """

    def __init__(self, output_size, neurons, code_size, gen_sample_batch_size, activation):
        self.vars = []
        with tf.name_scope("dense_generator"):
            with tf.variable_scope("generator_vars", reuse=tf.AUTO_REUSE):
                output = tf.distributions.Normal(tf.zeros(code_size), tf.ones(code_size)).sample(gen_sample_batch_size)
                # Build encoder network
                for i, n in enumerate(neurons):
                    w = tf.get_variable("w"+str(i), [output.shape[-1], n], initializer=tf.variance_scaling_initializer(), trainable=False)
                    b = tf.get_variable("b"+str(i), [n], initializer=tf.zeros_initializer(), trainable=False)
                    self.vars.append(w)
                    self.vars.append(b)
                    output = activation(tf.add(tf.matmul(output, w), b))
                # Build normal distribution with code_size
                w = tf.get_variable("w_loc", [output.shape[-1], output_size], initializer=tf.variance_scaling_initializer(), trainable=False)
                b = tf.get_variable("b_loc", [output_size], initializer=tf.zeros_initializer(), trainable=False)
                self.vars.append(w)
                self.vars.append(b)
                output = tf.add(tf.matmul(output, w), b)
                self.output = tf.reshape(tf.nn.sigmoid(output), [-1, output_size])
                self.distribution = tf.distributions.Bernoulli(output)

class dense_VAE(model):
    """
    Variational auto encoder with predefinded ELBO and output for sampling.
    """

    def __init__(self, x, y, b_replay, input_size, enc_neurons, code_size, dec_neurons, gen_sample_batch_size, thd, learning_rate):
        with tf.name_scope("vae"):
            # Build vae
            self.b_replay = b_replay
            self.gen_sample_batch_size = gen_sample_batch_size
            self.label = y
            self.gen = dense_generator(input_size, dec_neurons, code_size, self.gen_sample_batch_size, tf.nn.relu)
            x = tf.reshape(x, [-1, input_size])
            self.input = tf.cond(self.b_replay, lambda: tf.concat([x, self.gen.output], 0), lambda: x)
            # self.input = tf.cond(self.b_replay, lambda: self.gen.output, lambda: x) # Used for studying degeneration effects
            self.enc = dense_encoder(self.input, enc_neurons, code_size, tf.nn.relu)
            self.prior = tf.distributions.Normal(tf.zeros(code_size), tf.ones(code_size))
            self.posterior = self.enc.distribution
            self.code = self.posterior.sample()
            self.dec = dense_decoder(self.code, input_size, dec_neurons, tf.nn.relu)
            # Build the loss
            self.log_prob = self.dec.distribution.log_prob(tf.reshape(self.input, [-1, input_size]))
            self.log_likelihood = tf.reduce_sum(self.log_prob, axis=[1])
            self.kl_divergence = tf.reduce_sum(tf.distributions.kl_divergence(self.posterior, self.prior), axis=[1])
            self.elbo = self.log_likelihood - self.kl_divergence
            self.recon = self.dec.output
            self.anomaly_score = self.log_likelihood
            self.prediction = tf.where(tf.greater(self.anomaly_score, thd), tf.zeros_like(self.anomaly_score), tf.ones_like(self.anomaly_score))
            # Create optimizer and training step
            opt = tf.train.AdamOptimizer(learning_rate)
            self.loss = -1.0*tf.reduce_mean(self.elbo)
            self.update = opt.minimize(self.loss)
            # Create metrics for evaluation
            [acc, acc_update_op] = tf.metrics.accuracy(y, self.prediction)
            [auc, auc_update_op] = tf.metrics.auc(y, self.prediction, curve="PR", summation_method="careful_interpolation")
            [prec, prec_update_op] = tf.metrics.precision(y, self.prediction)
            [rec, rec_update_op] = tf.metrics.recall(y, self.prediction)
            [tp, tp_update_op] = tf.metrics.true_positives(y, self.prediction)
            [fp, fp_update_op] = tf.metrics.false_positives(y, self.prediction)
            [tn, tn_update_op] = tf.metrics.true_negatives(y, self.prediction)
            [fn, fn_update_op] = tf.metrics.false_negatives(y, self.prediction)
            self.metric_updates = tf.group(acc_update_op, auc_update_op, prec_update_op,\
                                    rec_update_op, tp_update_op, fp_update_op, tn_update_op,\
                                    fn_update_op)
            self.metrics = [acc, auc, prec, rec, tp, fp, tn, fn]
            self.metric_names = ["acc", "auc", "prec", "rec", "tp", "fp", "tn", "fn"]
            # Create summaries
            self.summaries = [tf.summary.scalar(name, metric) for name, metric in zip(self.metric_names, self.metrics)]
            self.merged_summaries = tf.summary.merge_all()

    def update_gen_weights(self, sess):
        for gen_var, dec_var in zip(self.gen.vars, self.dec.vars):
             sess.run(tf.assign(gen_var, dec_var))


class dense_discriminator(model):
    """
    Dense discriminator with arbitrary length and width.
    """

    def __init__(self, x, z, neurons, activation):
        self.vars = []
        with tf.name_scope("dense_discriminator"):
            with tf.variable_scope("dense_discriminator_vars", reuse=tf.AUTO_REUSE):
                output = x
                # Build encoder network
                for i, n in enumerate(neurons):
                    w = tf.get_variable("w"+str(i), [output.shape[-1], n], initializer=tf.variance_scaling_initializer())
                    b = tf.get_variable("b"+str(i), [n], initializer=tf.zeros_initializer())
                    self.vars.append(w)
                    self.vars.append(b)
                    output = activation(tf.add(tf.matmul(output, w), b))
                if (not z is None):
                    output = tf.concat([output, z], axis=1)
                self.feature = output
                # Build normal distribution with code_size
                w = tf.get_variable("w_loc", [output.shape[-1], 1], initializer=tf.variance_scaling_initializer())
                b = tf.get_variable("b_loc", [1], initializer=tf.zeros_initializer())
                self.vars.append(w)
                self.vars.append(b)
                self.logits = tf.add(tf.matmul(output, w), b)
                self.output = tf.reshape(tf.nn.sigmoid(self.logits ), [-1, 1])

class dense_ali_bi_gan(model):
    """
    Dense AliBiGAN with output for sampling.
    """

    def __init__(self, x, y, input_size, code_size, enc_neurons, dec_neurons, disc_neurons, gen_sample_batch_size, learning_rate, thd, b_replay):
        with tf.name_scope("ali_bi_gan"):
            # Build ali bi wasserstein_gan
            bn_relu = lambda x: tf.nn.leaky_relu(tf.layers.batch_normalization(x, training=True, center=False, scale=False), alpha=0.01)
            self.b_replay = b_replay
            self.gen_sample_batch_size = gen_sample_batch_size
            self.label = y
            self.gen = dense_generator(input_size, dec_neurons, code_size, gen_sample_batch_size, bn_relu)
            x = tf.reshape(x, [-1, input_size])
            self.input = tf.cond(self.b_replay, lambda: tf.concat([x, self.gen.output], 0), lambda: x)
            self.prior = tf.distributions.Normal(tf.zeros(code_size), tf.ones(code_size))
            self.z_hat = self.prior.sample(tf.shape(self.input)[0])
            self.dec = dense_decoder(self.z_hat, input_size, dec_neurons, bn_relu)
            self.enc = dense_encoder(self.input, enc_neurons, code_size, bn_relu)
            self.z = self.enc.loc
            self.disc_fake = dense_discriminator(self.dec.output, self.z_hat, disc_neurons, tf.nn.relu)
            self.disc_real = dense_discriminator(self.input, self.z, disc_neurons, tf.nn.relu)
            rand = tf.expand_dims(tf.distributions.Uniform().sample(tf.shape(self.input)[0]), axis=-1)
            self.interpol_img = tf.add(tf.multiply(rand, self.input), tf.multiply(rand, self.dec.output))
            self.interpol_latent = tf.add(tf.multiply(rand, self.z), tf.multiply(rand, self.z_hat))
            self.disc_interpol = dense_discriminator(self.interpol_img, self.interpol_latent, disc_neurons, tf.nn.relu)
            self.recon = dense_decoder(self.z, input_size, dec_neurons, bn_relu).output
            self.disc_recon = dense_discriminator(self.recon, self.z, disc_neurons, tf.nn.relu)
            # Build the loss
            self.loss_disc = tf.reduce_mean(tf.subtract(self.disc_fake.logits, self.disc_real.logits))
            self.loss_disc_interpol = tf.reduce_mean(tf.multiply(tf.constant(-1.0), self.disc_interpol.logits))
            grad_penalty = [tf.square(tf.subtract(tf.norm(g), tf.constant(1.0))) for g in tf.gradients(self.loss_disc_interpol, self.interpol_img)]
            self.loss_gen = tf.reduce_mean(tf.multiply(tf.constant(-1.0), self.disc_fake.logits))
            self.loss = tf.add(self.loss_gen, self.loss_disc)
            # Create optimizer
            opt_disc = tf.train.RMSPropOptimizer(learning_rate)
            opt_gen = tf.train.RMSPropOptimizer(learning_rate)
            update_disc = opt_disc.minimize(tf.add(self.loss_disc, tf.multiply(tf.constant(1.0), tf.reduce_sum(grad_penalty))), var_list=tf.trainable_variables("dense_discriminator_vars"))
            update_gen = opt_gen.minimize(self.loss_gen, var_list=tf.trainable_variables("encoder_vars")+tf.trainable_variables("decoder_vars"))
            self.update = [update_disc, update_gen]
            # Prediction for anomaly detection
            alpha = 0.5
            recon_loss = tf.norm(tf.subtract(self.input, self.recon), axis=-1, ord=1)
            disc_loss = tf.norm(tf.subtract(self.disc_real.feature, self.disc_recon.feature), axis=-1, ord=1)
            self.anomaly_score = tf.add(tf.multiply(alpha, recon_loss), tf.multiply(1.0-alpha, disc_loss))
            self.prediction = tf.where(tf.greater(self.anomaly_score, thd), tf.ones_like(self.anomaly_score), tf.zeros_like(self.anomaly_score))
            # Create metrics for evaluation
            [acc, acc_update_op] = tf.metrics.accuracy(y, self.prediction)
            [auc, auc_update_op] = tf.metrics.auc(y, self.prediction, curve="PR", summation_method="careful_interpolation")
            [prec, prec_update_op] = tf.metrics.precision(y, self.prediction)
            [rec, rec_update_op] = tf.metrics.recall(y, self.prediction)
            [tp, tp_update_op] = tf.metrics.true_positives(y, self.prediction)
            [fp, fp_update_op] = tf.metrics.false_positives(y, self.prediction)
            [tn, tn_update_op] = tf.metrics.true_negatives(y, self.prediction)
            [fn, fn_update_op] = tf.metrics.false_negatives(y, self.prediction)
            self.metric_updates = tf.group(acc_update_op, auc_update_op, prec_update_op,\
                                    rec_update_op, tp_update_op, fp_update_op, tn_update_op,\
                                    fn_update_op)
            self.metrics = [acc, auc, prec, rec, tp, fp, tn, fn]
            self.metric_names = ["acc", "auc", "prec", "rec", "tp", "fp", "tn", "fn"]
            # Create summaries
            self.summaries = [tf.summary.scalar(name, metric) for name, metric in zip(self.metric_names, self.metrics)]
            self.merged_summaries = tf.summary.merge_all()

    def update_gen_weights(self, sess):
        for gen_var, dec_var in zip(self.gen.vars, self.dec.vars):
             sess.run(tf.assign(gen_var, dec_var))

class dense_AAE(model):
    """
    Dense AAE with output for sampling.
    """

    def __init__(self, x, y, input_size, code_size, enc_neurons, dec_neurons, disc_neurons, gen_sample_batch_size, learning_rate, thd, b_replay):
        with tf.name_scope("dense_AAE"):
            # Build ali bi wasserstein_gan
            bn_relu = lambda x: tf.nn.leaky_relu(tf.layers.batch_normalization(x, training=True, center=False, scale=False), alpha=0.1)
            self.b_replay = b_replay
            self.gen_sample_batch_size = gen_sample_batch_size
            self.label = y
            self.gen = dense_generator(input_size, dec_neurons, code_size, gen_sample_batch_size, bn_relu)
            x = tf.reshape(x, [-1, input_size])
            self.input = tf.cond(self.b_replay, lambda: tf.concat([x, self.gen.output], 0), lambda: x)
            self.prior = tf.distributions.Normal(tf.zeros(code_size), tf.ones(code_size))
            self.z_hat = self.prior.sample(tf.shape(self.input)[0])
            self.enc = dense_encoder(self.input, enc_neurons, code_size, bn_relu)
            self.z = self.enc.distribution.sample()
            self.dec = dense_decoder(self.z, input_size, dec_neurons, bn_relu)
            self.disc_fake = dense_discriminator(self.z_hat, None, disc_neurons, tf.nn.relu)
            self.disc_real = dense_discriminator(self.z, None, disc_neurons, tf.nn.relu)
            self.recon = self.dec.output
            # Build the loss
            self.log_prob = self.dec.distribution.log_prob(self.input)
            self.log_likelihood = tf.reduce_sum(self.log_prob, axis=[1])
            self.loss_disc = tf.reduce_mean(tf.subtract(self.disc_real.logits, self.disc_fake.logits))
            self.loss_gen = -1.0*tf.reduce_mean(self.disc_real.logits)
            self.loss = tf.subtract(tf.add(self.loss_gen, self.loss_disc), tf.reduce_mean(self.log_likelihood))
            # Create optimizer
            update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
            with tf.control_dependencies(update_ops):
                opt_disc = tf.train.RMSPropOptimizer(learning_rate)
                opt_gen = tf.train.RMSPropOptimizer(learning_rate)
                self.update_disc = opt_disc.minimize(self.loss_disc, var_list=tf.trainable_variables("dense_discriminator_vars"))
                self.update_gen = opt_gen.minimize(tf.subtract(self.loss_gen, tf.reduce_mean(self.log_likelihood)), var_list=tf.trainable_variables("encoder_vars")+tf.trainable_variables("decoder_vars"))
                self.clip = [tf.clip_by_value(w, -0.01, 0.01) for w in tf.trainable_variables("dense_discriminator_vars")]
            # Prediction for anomaly detection
            self.anomaly_score = self.log_likelihood
            self.prediction = tf.where(tf.greater(self.anomaly_score, thd), tf.zeros_like(self.anomaly_score), tf.ones_like(self.anomaly_score))
            # Create metrics for evaluation
            [acc, acc_update_op] = tf.metrics.accuracy(y, self.prediction)
            [auc, auc_update_op] = tf.metrics.auc(y, self.prediction, curve="PR", summation_method="careful_interpolation")
            [prec, prec_update_op] = tf.metrics.precision(y, self.prediction)
            [rec, rec_update_op] = tf.metrics.recall(y, self.prediction)
            [tp, tp_update_op] = tf.metrics.true_positives(y, self.prediction)
            [fp, fp_update_op] = tf.metrics.false_positives(y, self.prediction)
            [tn, tn_update_op] = tf.metrics.true_negatives(y, self.prediction)
            [fn, fn_update_op] = tf.metrics.false_negatives(y, self.prediction)
            self.metric_updates = tf.group(acc_update_op, auc_update_op, prec_update_op,\
                                    rec_update_op, tp_update_op, fp_update_op, tn_update_op,\
                                    fn_update_op)
            self.metrics = [acc, auc, prec, rec, tp, fp, tn, fn]
            self.metric_names = ["acc", "auc", "prec", "rec", "tp", "fp", "tn", "fn"]
            # Create summaries
            self.summaries = [tf.summary.scalar(name, metric) for name, metric in zip(self.metric_names, self.metrics)]
            self.merged_summaries = tf.summary.merge_all()

    def update_gen_weights(self, sess):
        for gen_var, dec_var in zip(self.gen.vars, self.dec.vars):
             sess.run(tf.assign(gen_var, dec_var))
